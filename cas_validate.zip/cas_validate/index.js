module.exports = require('./lib/cas_validate.js');
